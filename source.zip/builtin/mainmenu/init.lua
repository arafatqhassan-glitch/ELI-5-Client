-- Minetest / Luanti Main Menu Initialization Script

local menupath = core.get_mainmenu_path()

dofile(menupath .. DIR_DELIM .. "async_engine.lua")
dofile(menupath .. DIR_DELIM .. "tabview.lua")
dofile(menupath .. DIR_DELIM .. "dlg_confirm_url.lua")
dofile(menupath .. DIR_DELIM .. "dlg_create_world.lua")
dofile(menupath .. DIR_DELIM .. "dlg_delete_content.lua")
dofile(menupath .. DIR_DELIM .. "dlg_delete_world.lua")
dofile(menupath .. DIR_DELIM .. "dlg_rename_modpack.lua")
dofile(menupath .. DIR_DELIM .. "dlg_version_info.lua")
dofile(menupath .. DIR_DELIM .. "pkgmgr.lua")
dofile(menupath .. DIR_DELIM .. "serverlist.lua")
dofile(menupath .. DIR_DELIM .. "store.lua")

-- Developer Lite Mode preset handler
local function apply_lite_mode(enabled)
	if enabled then
		core.settings:set("enable_shaders", "false")
		core.settings:set("enable_particles", "false")
		core.settings:set("enable_fog", "false")
		core.settings:set("enable_3d_clouds", "false")
		core.settings:set("shadow_map_max_distance", "0")
		core.settings:set("viewing_range", "20")
		core.settings:set("fps_max", "60")
		core.settings:set("pause_fps_max", "15")
		core.settings:set("smooth_lighting", "false")
	else
		core.settings:set("enable_shaders", "true")
		core.settings:set("enable_particles", "true")
		core.settings:set("enable_fog", "true")
		core.settings:set("enable_3d_clouds", "true")
		core.settings:set("viewing_range", "100")
		core.settings:set("smooth_lighting", "true")
	end
	core.settings:save()
end

local tabs = {
	content     = dofile(menupath .. DIR_DELIM .. "tab_content.lua"),
	about       = dofile(menupath .. DIR_DELIM .. "tab_about.lua"),
	local_game  = dofile(menupath .. DIR_DELIM .. "tab_local.lua"),
	play_online = dofile(menupath .. DIR_DELIM .. "tab_online.lua")
}

local function main_event_handler(event)
	local current_lite = core.settings:get_bool("eli_lite_mode", false)
	apply_lite_mode(current_lite)

	if event == "MenuQuit" then
		local show_dialog = core.settings:get_bool("pause_fps_max", false)
		if not ui.childlist["mainmenu_quit"] then
			tabview:hide()
			local dlg = create_exit_dialog()
			dlg:set_parent(tabview)
			dlg:show()
		else
			core.close()
		end
		return true
	end
	return true
end

core.register_on_mainloop(function()
	local current_lite = core.settings:get_bool("eli_lite_mode", false)
	apply_lite_mode(current_lite)
end)

tabview = create_tabview()
for name, tab in pairs(tabs) do
	tabview:add(name, tab)
end

core.register_on_mainmenu_tab_change(function(tab)
	tabview:show_tab(tab)
end)